#pragma once

#include "common.h"

// Get the current tick time in seconds
bool utils_gettime(double *pTime);
