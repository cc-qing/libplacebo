#pragma once

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <libplacebo/log.h>
#include <libplacebo/renderer.h>

#include "config_demos.h"
