#include <libplacebo/@header@>

int main()
{
    return 0;
}
