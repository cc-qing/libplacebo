#include "vulkan/vk_icd.h"

int main()
{
    return 0;
}
