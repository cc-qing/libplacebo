#[allow(clippy::all)]
pub mod {{ spec.name }};